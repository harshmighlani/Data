package com.centurylink.test.gitHubFollower.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

//@Repository
public class SampleDAOImpl{

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public List<Object> all() {

        return jdbcTemplate.query("SELECT * FROM Employee",
                BeanPropertyRowMapper.newInstance(Object.class));
    }

    public Object findById(Long id) {

        String sql = "SELECT * FROM cars WHERE id=?";

        return jdbcTemplate.queryForObject(sql,Object.class);
    }
}