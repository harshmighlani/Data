package com.centurylink.test.gitHubFollower.component;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope(value = "prototype")
public class AllStrategiesExampleBean implements InitializingBean {

	public AllStrategiesExampleBean() {
		System.out.println("Constructor");
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		System.out.println("InitializingBean");
	}

	@PostConstruct
	public void postConstruct() {
		System.out.println("PostConstruct");
	}

	public void init() {
		System.out.println("init-method");
	}
}