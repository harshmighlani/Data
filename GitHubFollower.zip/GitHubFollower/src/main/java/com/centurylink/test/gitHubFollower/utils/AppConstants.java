package com.centurylink.test.gitHubFollower.utils;

public final class AppConstants {

	public static final String GITHUB_URL="github.url";
	public static final String  FOLLOWER_SERVICE_URL="fetchGitHubFollowersService";
	
	public static final String  SLASH="//";
	public static final String  FOLLOWERS="followers";
}
